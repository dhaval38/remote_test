from django.contrib import admin
from blog.models import uploadCsv

admin.site.register(uploadCsv)
