from django import forms

class uploadCsvFile(forms.Form):
    """Form to handle upload csv file functionality"""
    docFile = forms.FileField(
        label = 'Select a file', help_text = 'Upload .csv file')

class crossTabulation(forms.Form):
    """Form to handle cross tabulation functionality"""
    column1 = forms.ChoiceField(choices=[], label='column1')
    column2 = forms.ChoiceField(choices=[], label='column2')

#def _init_(self, *args, **kwargs):
#    super(crossTabulation, self).__init__(*args, **kwargs)

#    self.fields['column1'].choices = [(x.pk, x.column1) for x in uploadCsv.objects.distinct()]
#    self.fields['column2'].choices = [(x.pk, x.column2) for x in uploadCsv.objects.distinct()]
