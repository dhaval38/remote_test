from django.db import models

class uploadCsv(models.Model):
    """ Model to handle upload file field """
    name = models.CharField(max_length=30)
    docFile = models.FileField(upload_to=".")
