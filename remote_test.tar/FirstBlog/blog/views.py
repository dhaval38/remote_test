from django.shortcuts import render_to_response
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.conf import settings

from blog.models import uploadCsv
from blog.forms import uploadCsvFile
from blog.forms import crossTabulation
import csv
import chardet
import StringIO
import pandas

def home(request):
    # Get input data from "uploadForm"
    if request.method == "POST" and "uploadForm" in request.POST:

        # Get uploaded file from "uploadForm"
        form = uploadCsvFile(request.POST, request.FILES)
        crossTab = crossTabulation()

        # Check if form submission is valid or not
        if form.is_valid():
            # Get file content from uploaded file
            fileContent = request.FILES['docFile'].read()
            # Get file encoding
            encoding = chardet.detect(fileContent)['encoding']
            if encoding != "utf-8":
                fileContent = fileContent.decode(encoding, 'replace').encode("utf-8")

            # Convert string to filestream
            filestream = StringIO.StringIO(fileContent)
            # Get dialect
            dialect = csv.Sniffer().sniff(fileContent)
                         
            # Read entire csv file     
            reader = csv.DictReader(filestream.read().splitlines(), 
                dialect=dialect)  
            col = {}
            # Get headers from csv file
            columns = reader.fieldnames
            crossTab.fields['column1'].choices = columns
            crossTab.fields['column2'].choices = columns
            for i in range(len(columns)):
                col[i] = columns[i]
   
            data = {}
            # Save uploaded csv file to MEDIA_ROOT
            newDoc = uploadCsv(docFile = request.FILES['docFile'])
            newDoc.save()

            # Redirect to same page
            return render(request, 'index.html', {'columns' : col, 
                'form' : form, 'crossTabForm' : crossTab, 'reader' : reader})

        else:
            # Handle invalid form submission
            # Need proper error handling mechanism
            print "Form is invalid"
            message = {'message' : "Please upload file"}
            form = uploadCsvFile()
            return render(request, 'index.html', locals())

    # Check if input data is from "cossTabForm"
    elif request.method == "POST" and "crossTabForm" in request.POST:
        col = {}
        data = {}
        form = uploadCsvFile()
        crossTab = crossTabulation(data=request.POST)
     
        # Get column names for performing cross tabulation
        index = request.POST['column1']
        column = request.POST['column2']
        
        entries = uploadCsv.objects.latest('docFile')
        file = str(entries.docFile)[1:]
        file = settings.MEDIA_ROOT + file
        data_csv = pandas.read_csv(file)
 
        # Set column names in drop down list
        headers = list(data_csv.columns.values)
        crossTab.fields['column1'].choices = headers
        crossTab.fields['column2'].choices = headers

        # Perform cross tabulation on selected columns
        result = pandas.crosstab(data_csv["%s" %(index)],
            data_csv["%s" %(column)])
        return render(request, 'index.html', {'fileData' : data_csv.to_html(), 
            'crossTabForm': crossTab, 'form' : form, 
            'data' : result.to_html(classes = "table table-striped")})
 
    else:
        form = uploadCsvFile()
        crossTab = crossTabulation()
        data = {}
        col = {}

    # Submit forms with required data 
    return render_to_response('index.html', {'columns' : col, 'reader' : data, 
        'form' : form, 'crossTabForm' : crossTab }, context_instance=RequestContext(request))
